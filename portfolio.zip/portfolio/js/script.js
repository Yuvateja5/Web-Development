// about button actions
document.getElementById('b').onclick = function(){
    document.getElementById('h1').innerHTML="Junior Developer";
    document.getElementById('h2').innerHTML="Skfter Education";
    document.getElementById('h3').innerHTML="BE Graduate";
    document.getElementById('visible').style.display='none';
    document.getElementById('hidden').style.display='block';

}


// click the home link in the navigation bar to see home page
document.getElementById('home').onclick = function(){
    document.getElementById('h1').innerHTML="Hi there,";
    document.getElementById('h2').innerHTML="This is Yuvateja";
    document.getElementById('h3').innerHTML="Software Engineer"

}

// click the education link in the navigation bar to see educational qualification
document.getElementById('education').onclick = function(){
    document.getElementById('h1').innerHTML="BE-CSE(8.66 CGPA)";
    document.getElementById('h2').innerHTML="HSC(68.8%)";
    document.getElementById('h3').innerHTML="SSLC(84.8%)"

}

// click the skills link in the navigation bar to see the skills
document.getElementById('skills').onclick = function(){
    document.getElementById('h1').innerHTML="Web Development";
    document.getElementById('h2').innerHTML="Machine Learning";
    document.getElementById('h3').innerHTML="DBMS"

}

// click the home link in the navigation bar to see the contact details
document.getElementById('contact').onclick = function(){
    document.getElementById('h1').innerHTML="0123456789";
    document.getElementById('h2').innerHTML="abc@gmail.com";
    document.getElementById('h3').innerHTML="Chennai"

}

// document.getElementId-it is a method which is used to access an html elements by its unique Id 
//  onclick= it is an event attribute which is mainly used to define a function or set of actions that should happen wen user clicks on specific html element,it is often used with links ,buttons or other interactive elements
// innerHTML= used to set the HTML content inside an HTML Element,its a quick way to dynamically change the content of an element on a web page.


